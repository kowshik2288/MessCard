const express = require('express');
const router = express.Router();

// Import controller methods
const {
  vendorRegister,
  vendorLogin,
  getAllVendors,
  getVendorById
} = require('../controllers/vendorController');

// Routes
router.post('/register', vendorRegister); // POST /vendor/register
router.post('/login', vendorLogin);       // POST /vendor/login
router.get('/all-vendors', getAllVendors); // GET /vendor/all-vendors
router.get('/single-vendor/:id', getVendorById); // GET /vendor/single-vendor/:id

module.exports = router;
