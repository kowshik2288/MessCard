const Vendor = require('../models/Vendor');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv'); 

dotenv.config();
const secretKey = process.env.WhatIsYourName; // Ensure this key exists in .env

// Register Vendor
const vendorRegister = async (req, res) => {
    const { username, email, password } = req.body;

    try {
        const existingVendor = await Vendor.findOne({ email });
        if (existingVendor) {
            return res.status(400).json({ error: "Email already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newVendor = new Vendor({
            username,
            email,
            password: hashedPassword,
            
        });

        await newVendor.save();

        console.log('Vendor registered:', email);
        res.status(201).json({ message: "Vendor registered successfully" });

    } catch (error) {
        console.error('Registration Error:', error);
        res.status(500).json({ error: "Internal server error" });
    }
};

// Vendor Login
const vendorLogin = async (req, res) => {
    const { email, password } = req.body;

    try {
        const vendor = await Vendor.findOne({ email });

        if (!vendor || !(await bcrypt.compare(password, vendor.password))) {
            return res.status(401).json({ error: "Invalid credentials" });
        }

        const token = jwt.sign({ vendorId: vendor._id }, secretKey, { expiresIn: '1h' });

        console.log('Login successful:', email);
        res.status(200).json({ success: "Login successful", token });

    } catch (error) {
        console.error('Login Error:', error);
        res.status(500).json({ error: "Internal server error" });
    }
};

const getVendor = async (req, res) => {
  try {
    const vendor = await Vendor.findById(req.params.id).populate("firm");
    res.json(vendor);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get All Vendors
const getAllVendors = async (req, res) => {
    try {
        const vendors = await Vendor.find().populate('firm');
        res.status(200).json({ vendors });
    } catch (error) {
        console.error('Fetching vendors failed:', error);
        res.status(500).json({ error: "Internal server error" });
    }
};

// Get Vendor by ID
const getVendorById = async (req, res) => {
    const vendorId = req.params.id;

    try {
        const vendorData = await Vendor.findById(vendorId).populate('firm');
        
        if (!vendorData) {
            return res.status(404).json({ error: "Vendor not found" });
        }

        const vendorFirmId = vendorData.firm?._id || vendorData.firm[0]?._id || null;

        res.status(200).json({ vendorFirmId });
        console.log("Vendor firm ID:", vendorFirmId);
        
    } catch (error) {
        console.error('Fetching vendor by ID failed:', error);
        res.status(500).json({ error: "Internal server error" });
    }
};

module.exports = {
    vendorRegister,
    vendorLogin,
    getAllVendors,
    getVendorById
    
};
